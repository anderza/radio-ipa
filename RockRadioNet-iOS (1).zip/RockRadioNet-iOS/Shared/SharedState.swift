import Foundation
import UIKit

/// Данные, общие для приложения и виджета (через App Group).
enum Shared {
    static let group = "group.com.rockradionet.player"
    static let widgetKind = "RadioWidget"

    static var defaults: UserDefaults { UserDefaults(suiteName: group) ?? .standard }

    /// Файл с текущей картинкой (обложка или логотип) для виджета.
    static var coverFile: URL? {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group)?
            .appendingPathComponent("cover.jpg")
    }

    struct State: Codable, Equatable {
        var hasStations = false
        var hasCurrent = false
        var name = ""
        var genre = ""
        var artist = ""
        var title = ""
        var playing = false
        var error = ""
        var coverStamp = "" // меняется, когда меняется картинка
    }

    static func save(_ s: State) {
        if let data = try? JSONEncoder().encode(s) {
            defaults.set(data, forKey: "widgetState")
        }
    }

    static func load() -> State {
        guard let data = defaults.data(forKey: "widgetState"),
              let s = try? JSONDecoder().decode(State.self, from: data) else { return State() }
        return s
    }

    /// Цвет станции — тот же алгоритм, что hue() в веб-интерфейсе (HSL 55% / 45%).
    static func stationColor(_ name: String) -> UIColor {
        var h = 0
        for u in name.unicodeScalars { h = (h * 31 + Int(u.value)) % 360 }
        // HSL(h, 55%, 45%) → HSB(h, 0.7097, 0.6975)
        return UIColor(hue: CGFloat(h) / 360.0, saturation: 0.7097, brightness: 0.6975, alpha: 1)
    }
}
