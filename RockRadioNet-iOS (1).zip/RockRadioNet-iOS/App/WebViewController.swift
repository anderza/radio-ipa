import UIKit
import WebKit

/// Окно приложения: тот же интерфейс, что и HTML-версия (www/index.html).
/// Страница управляет нативным плеером через window.Android — тот же мост, что в Android-версии.
final class WebViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {

    private var web: WKWebView!
    private let radio = RadioController.shared

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        let bg = UIColor(red: 0x12 / 255.0, green: 0x14 / 255.0, blue: 0x1C / 255.0, alpha: 1)
        view.backgroundColor = bg

        let shim = """
        (function(){
          var h=window.webkit.messageHandlers.rr;
          var post=function(m){h.postMessage({m:m,a:Array.prototype.slice.call(arguments,1)})};
          window.__st=JSON.stringify(\(radio.stateJSON()));
          window.Android={
            isNative:function(){return true},
            isTv:function(){return false},
            getState:function(){return window.__st||"null"},
            setStations:function(j){post("setStations",j)},
            play:function(i){post("play",i)},
            pause:function(){post("pause")},
            toggle:function(){post("toggle")},
            next:function(){post("next")},
            prev:function(){post("prev")},
            setVolume:function(v){post("setVolume",v)},
            openUrl:function(u){post("openUrl",u)},
            saveText:function(n,t){post("saveText",n,t)},
            setCoverMode:function(m){post("setCoverMode",m)}
          };
        })();
        """

        let config = WKWebViewConfiguration()
        let ucc = WKUserContentController()
        ucc.addUserScript(WKUserScript(source: shim, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        ucc.add(WeakHandler(self), name: "rr")
        config.userContentController = ucc
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.websiteDataStore = .default()

        web = WKWebView(frame: .zero, configuration: config)
        web.isOpaque = false
        web.backgroundColor = bg
        web.scrollView.backgroundColor = bg
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.scrollView.bounces = false
        web.navigationDelegate = self
        web.uiDelegate = self
        web.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(web)
        NSLayoutConstraint.activate([
            web.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            web.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            web.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            web.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])

        if let index = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "www") {
            web.loadFileURL(index, allowingReadAccessTo: index.deletingLastPathComponent())
        }

        radio.onChange = { [weak self] in self?.pushState() }
    }

    private func pushState() {
        guard let web else { return }
        let s = radio.stateJSON()
        web.evaluateJavaScript("window.__st=JSON.stringify(\(s));window.nativeState&&window.nativeState(\(s));",
                               completionHandler: nil)
    }

    // MARK: - Сообщения со страницы

    func userContentController(_ ucc: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any], let m = body["m"] as? String else { return }
        let a = body["a"] as? [Any] ?? []
        func num(_ i: Int) -> Double? { a.count > i ? (a[i] as? NSNumber)?.doubleValue : nil }
        func str(_ i: Int) -> String? { a.count > i ? a[i] as? String : nil }

        switch m {
        case "setStations":
            if let j = str(0) { radio.setStations(json: j) }
        case "play":
            radio.handle(.play, index: Int(num(0) ?? -1))
        case "pause":
            radio.handle(.pause)
        case "toggle":
            radio.handle(.toggle)
        case "next":
            radio.handle(.next)
        case "prev":
            radio.handle(.prev)
        case "setVolume":
            if let v = num(0) { radio.setVolume(Float(v)) }
        case "setCoverMode":
            if let v = str(0) { radio.setCoverMode(v) }
        case "openUrl":
            if let u = str(0), let url = URL(string: u) { UIApplication.shared.open(url) }
        case "saveText":
            if let name = str(0), let text = str(1) { share(name: name, text: text) }
        default:
            break
        }
    }

    private func share(name: String, text: String) {
        let file = FileManager.default.temporaryDirectory.appendingPathComponent(name)
        do {
            try text.data(using: .utf8)?.write(to: file, options: .atomic)
        } catch {
            return
        }
        let vc = UIActivityViewController(activityItems: [file], applicationActivities: nil)
        vc.popoverPresentationController?.sourceView = view
        vc.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        present(vc, animated: true)
    }

    // MARK: - Ссылки и диалоги

    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let url = action.request.url, url.scheme == "http" || url.scheme == "https",
           action.targetFrame?.isMainFrame ?? true {
            UIApplication.shared.open(url)
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = action.request.url { UIApplication.shared.open(url) }
        return nil
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let ac = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        present(ac, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let ac = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "Отмена", style: .cancel) { _ in completionHandler(false) })
        ac.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        present(ac, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String,
                 defaultText: String?, initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (String?) -> Void) {
        let ac = UIAlertController(title: nil, message: prompt, preferredStyle: .alert)
        ac.addTextField { $0.text = defaultText }
        ac.addAction(UIAlertAction(title: "Отмена", style: .cancel) { _ in completionHandler(nil) })
        ac.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(ac.textFields?.first?.text) })
        present(ac, animated: true)
    }
}

/// Обёртка, чтобы WKUserContentController не удерживал контроллер навсегда.
private final class WeakHandler: NSObject, WKScriptMessageHandler {
    weak var target: WKScriptMessageHandler?
    init(_ t: WKScriptMessageHandler) { target = t }
    func userContentController(_ ucc: WKUserContentController, didReceive message: WKScriptMessage) {
        target?.userContentController(ucc, didReceive: message)
    }
}
